// Fill out your copyright notice in the Description page of Project Settings.


#include "TCPSocket.h"
#include "Networking.h"
#define BUFFERSIZE 2*1024*1024
UTCPSocket::UTCPSocket(const FObjectInitializer& ObjectInitializer):Super(ObjectInitializer)
{
}

bool UTCPSocket::CreateSocket(const FString& InSocketName, const FString& InHost, const int32 InPort)
{
	FScopeLock lock(&SocketMt);
	FIPv4Address BindToAddr;
	bool bResult = FIPv4Address::Parse(InHost, BindToAddr);
	checkf(bResult, TEXT("Failed to parse IPv4 address %s"), *InHost);

	Socket = FTcpSocketBuilder(InSocketName)
		.AsNonBlocking()
		.WithSendBufferSize(BUFFERSIZE)
		.BoundToAddress(BindToAddr)
		.BoundToPort(InPort)
		.Build();

	TSharedRef<FInternetAddr> InternetAddr = ISocketSubsystem::Get(PLATFORM_SOCKETSUBSYSTEM)->CreateInternetAddr();
	InternetAddr->SetIp(BindToAddr.Value);
	InternetAddr->SetPort(InPort);

	bResult = Socket ? Socket->Connect(*InternetAddr) : false;

	return bResult;
}

bool UTCPSocket::Send(const uint8* Data, uint32 Size)
{
	FScopeLock Lock(&SocketMt);
	if (!Socket)
	{
		return false;
	}
	int32 byteSent;
	return Socket->Send(Data, Size, byteSent);
}

void UTCPSocket::Recv(uint8* Data,int32& Size)
{
	int32 BytesRead = 0;
	if (Socket)
	{
		Socket->Recv(Data, Size, BytesRead);
	}
}
