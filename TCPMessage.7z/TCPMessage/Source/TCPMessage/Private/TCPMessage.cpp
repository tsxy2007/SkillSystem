// Copyright 1998-2019 Epic Games, Inc. All Rights Reserved.

#include "TCPMessage.h"
#include "Core.h"
#include "Modules/ModuleManager.h"
#include "Interfaces/IPluginManager.h"

#define LOCTEXT_NAMESPACE "FTCPMessageModule"

void FTCPMessageModule::StartupModule()
{
	
}

void FTCPMessageModule::ShutdownModule()
{
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FTCPMessageModule, TCPMessage)
