// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ObjectMacros.h"
#include "Misc/ScopeLock.h"
#include "TCPSocket.generated.h"

class FSocket;
/**
 * 
 */
UCLASS()
class TCPMESSAGE_API UTCPSocket : public UObject
{
	GENERATED_UCLASS_BODY()
public:
	bool CreateSocket(const FString& InSocketName, const FString& InHost, const int32 InPost);
	
	bool Send(const uint8* Data, uint32 Size);

	void Recv();
private:
	FSocket* Socket;
	FCriticalSection SocketMt;
};
